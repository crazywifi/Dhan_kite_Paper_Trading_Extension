// background.js — toggles the floating panel when extension icon is clicked
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || !tab.url.includes('kite.zerodha.com')) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_PANEL' });
  } catch (e) {
    // content script might not be ready yet
  }
});
