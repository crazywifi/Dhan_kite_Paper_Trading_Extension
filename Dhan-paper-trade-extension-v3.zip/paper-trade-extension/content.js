// ─── PAPER TRADE — DHAN CONTENT SCRIPT ──────────────────────────────────────
(function () {
  'use strict';

  const PANEL_ID   = 'pt-panel-root';
  const PT_OPTIONS = [10, 20, 30, 40, 50];

  // ─── LOT SIZE CONFIG ───────────────────────────────────────────────────────
  const LOT_SIZES = {
    NIFTY     : 65,
    BANKNIFTY : 30,
    DEFAULT   : 1,
  };

  function detectInstrument() {
    const text = (document.title + ' ' + window.location.href).toUpperCase();
    if (text.includes('BANKNIFTY') || text.includes('BANK NIFTY')) return 'BANKNIFTY';
    if (text.includes('NIFTY')) return 'NIFTY';
    const headers = document.querySelectorAll('h1,h2,[class*="symbol"],[class*="scrip"],[class*="instrument"]');
    for (const el of headers) {
      const t = el.textContent.toUpperCase();
      if (t.includes('BANKNIFTY') || t.includes('BANK NIFTY')) return 'BANKNIFTY';
      if (t.includes('NIFTY')) return 'NIFTY';
    }
    return 'NIFTY'; // default to NIFTY
  }

  function getLotSize(instrument) {
    return LOT_SIZES[instrument] ?? LOT_SIZES.DEFAULT;
  }

  // ─── STATE ────────────────────────────────────────────────────────────────
  let state = {
    targetPts  : 30,
    slPts      : 20,
    direction  : 'BUY',
    lots       : 1,
    lotSize    : 65,
    instrument : 'NIFTY',
    inTrade    : false,
    entryPrice : null,
    targetPrice: null,
    slPrice    : null,
    pnl        : 0,
    totalPnl   : 0,
    trades     : [],
    price      : null,
    prevPrice  : null,
  };

  function totalQty() { return state.lots * state.lotSize; }

  let intervalId   = null;
  let panelVisible = false;

  // ─── TOGGLE ───────────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'TOGGLE_PANEL') panelVisible ? hidePanel() : showPanel();
  });

  function showPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) { existing.style.display = 'block'; panelVisible = true; return; }

    const instrument = detectInstrument();
    state.instrument = instrument;
    state.lotSize    = getLotSize(instrument);

    chrome.storage.local.get(
      ['targetPts','slPts','direction','lots','lotSize','instrument','totalPnl','trades','panelX','panelY'],
      (d) => {
        if (d.targetPts)  state.targetPts  = d.targetPts;
        if (d.slPts)      state.slPts      = d.slPts;
        if (d.direction)  state.direction  = d.direction;
        if (d.lots)       state.lots       = d.lots;
        if (d.instrument === instrument && d.lotSize) state.lotSize = d.lotSize;
        if (d.totalPnl !== undefined) state.totalPnl = d.totalPnl;
        if (d.trades)     state.trades     = d.trades;
        const x = d.panelX ?? (window.innerWidth - 310 - 20);
        const y = d.panelY ?? 80;
        injectCSS();
        buildPanel(x, y);
        panelVisible = true;
        startPricePoll();
      }
    );
  }

  function hidePanel() {
    const el = document.getElementById(PANEL_ID);
    if (el) el.style.display = 'none';
    panelVisible = false;
  }

  // ─── CSS ──────────────────────────────────────────────────────────────────
  function injectCSS() {
    if (document.getElementById('pt-css')) return;
    const s = document.createElement('style');
    s.id = 'pt-css';
    s.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@600;700;800&display=swap');
      #pt-panel-root { position:fixed;z-index:2147483647;width:300px;font-family:'Syne','Segoe UI',sans-serif;filter:drop-shadow(0 20px 60px rgba(0,0,0,.85)); }
      .pt { background:#0d1117;border:1px solid #1e2535;border-radius:14px;overflow:hidden; }
      .pt-bar { display:flex;align-items:center;gap:8px;padding:9px 12px;background:#111520;border-bottom:1px solid #1e2535;cursor:grab; }
      .pt-bar:active{cursor:grabbing;}
      .pt-logo { width:22px;height:22px;border-radius:6px;flex-shrink:0;background:linear-gradient(135deg,#f59e0b,#ef4444);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff; }
      .pt-title{font-size:12px;font-weight:800;color:#e8ecf4;letter-spacing:-.2px;}
      .pt-badge { margin-left:auto;display:flex;align-items:center;gap:4px;font-size:9px;font-weight:700;font-family:'JetBrains Mono',monospace;padding:2px 7px;border-radius:20px;background:#181d2a;border:1px solid #1e2535;color:#6b7a99;transition:all .3s; }
      .pt-badge.live{background:rgba(0,230,118,.08);border-color:rgba(0,230,118,.3);color:#00e676;}
      .pt-badge.intrade{background:rgba(245,158,11,.12);border-color:rgba(245,158,11,.4);color:#f59e0b;}
      .pt-dot{width:5px;height:5px;border-radius:50%;background:currentColor;}
      .pt-badge.live .pt-dot,.pt-badge.intrade .pt-dot{animation:pt-pulse 1.4s infinite;box-shadow:0 0 4px currentColor;}
      @keyframes pt-pulse{0%,100%{opacity:1}50%{opacity:.2}}
      .pt-x { width:18px;height:18px;border-radius:50%;background:rgba(255,68,68,.15);border:1px solid rgba(255,68,68,.3);color:#ff4444;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:10px;margin-left:5px;transition:background .15s; }
      .pt-x:hover{background:rgba(255,68,68,.3);}
      .pt-price{padding:10px 13px 8px;background:#111520;border-bottom:1px solid #1e2535;}
      .pt-lbl{font-size:8px;text-transform:uppercase;letter-spacing:1.5px;color:#6b7a99;font-weight:600;margin-bottom:3px;font-family:'JetBrains Mono',monospace;}
      .pt-price-row{display:flex;align-items:baseline;gap:3px;}
      .pt-psym{font-size:11px;color:#6b7a99;}
      .pt-pval{font-size:26px;font-weight:800;font-family:'JetBrains Mono',monospace;color:#e8ecf4;letter-spacing:-1.5px;transition:color .25s;}
      .pt-pval.up{color:#00e676;}.pt-pval.down{color:#ff4444;}
      .pt-ptime{font-size:9px;color:#6b7a99;margin-top:1px;font-family:'JetBrains Mono',monospace;}
      .pt-pnl-bar{padding:8px 13px;border-bottom:1px solid #1e2535;display:flex;align-items:center;justify-content:space-between;background:#0f1520;}
      .pt-pnl-block{text-align:center;}
      .pt-pnl-lbl{font-size:8px;text-transform:uppercase;letter-spacing:1.2px;color:#6b7a99;font-weight:600;font-family:'JetBrains Mono',monospace;margin-bottom:2px;}
      .pt-pnl-val{font-size:18px;font-weight:800;font-family:'JetBrains Mono',monospace;letter-spacing:-1px;}
      .pt-pnl-val.pos{color:#00e676;}.pt-pnl-val.neg{color:#ff4444;}.pt-pnl-val.zero{color:#6b7a99;}
      .pt-divider{width:1px;height:36px;background:#1e2535;}
      .pt-total-lbl{font-size:8px;text-transform:uppercase;letter-spacing:1.2px;color:#6b7a99;font-weight:600;font-family:'JetBrains Mono',monospace;margin-bottom:2px;}
      .pt-total-val{font-size:14px;font-weight:800;font-family:'JetBrains Mono',monospace;}
      .pt-total-val.pos{color:#00e676;}.pt-total-val.neg{color:#ff4444;}.pt-total-val.zero{color:#6b7a99;}
      .pt-trade-info{display:none;padding:8px 13px;border-bottom:1px solid #1e2535;background:rgba(245,158,11,.04);}
      .pt-trade-info.show{display:block;}
      .pt-ti-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;}
      .pt-ti-lbl{font-size:9px;color:#6b7a99;font-family:'JetBrains Mono',monospace;}
      .pt-ti-val{font-size:10px;font-weight:700;font-family:'JetBrains Mono',monospace;color:#e8ecf4;}
      .pt-ti-tgt{color:#00e676 !important;}.pt-ti-sl{color:#ff4444 !important;}
      .pt-progress{height:4px;background:#1e2535;border-radius:2px;margin-top:5px;overflow:hidden;}
      .pt-progress-fill{height:100%;border-radius:2px;transition:width .5s,background .3s;}
      .pt-dir{padding:9px 13px;border-bottom:1px solid #1e2535;}
      .pt-dir-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:5px;}
      .pt-dbtn{padding:8px;border-radius:8px;border:1.5px solid #1e2535;background:#181d2a;font-size:12px;font-weight:800;cursor:pointer;text-align:center;color:#6b7a99;transition:all .15s;letter-spacing:.5px;font-family:'Syne','Segoe UI',sans-serif;}
      .pt-dbtn:hover{color:#e8ecf4;}
      .pt-dbtn.ba{background:rgba(0,230,118,.1);border-color:#00e676;color:#00e676;box-shadow:0 0 10px rgba(0,230,118,.15);}
      .pt-dbtn.sa{background:rgba(255,68,68,.1);border-color:#ff4444;color:#ff4444;box-shadow:0 0 10px rgba(255,68,68,.15);}
      .pt-dbtn:disabled{opacity:.4;cursor:not-allowed;}
      .pt-tsl{display:grid;grid-template-columns:1fr 1fr;gap:6px;padding:9px 13px;border-bottom:1px solid #1e2535;}
      .pt-tbox{padding:8px 9px;border-radius:8px;text-align:center;}
      .pt-tbox.t{background:rgba(0,230,118,.07);border:1px solid rgba(0,230,118,.2);}
      .pt-tbox.s{background:rgba(255,68,68,.07);border:1px solid rgba(255,68,68,.2);}
      .pt-tlbl{font-size:7px;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;margin-bottom:2px;font-family:'JetBrains Mono',monospace;}
      .pt-tbox.t .pt-tlbl{color:#00e676;}.pt-tbox.s .pt-tlbl{color:#ff4444;}
      .pt-tval{font-size:14px;font-weight:800;font-family:'JetBrains Mono',monospace;letter-spacing:-.5px;}
      .pt-tbox.t .pt-tval{color:#00e676;}.pt-tbox.s .pt-tval{color:#ff4444;}
      .pt-tsub{font-size:8px;color:#6b7a99;margin-top:1px;font-family:'JetBrains Mono',monospace;}
      .pt-pts{padding:9px 13px;border-bottom:1px solid #1e2535;}
      .pt-plbl{font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:4px;font-family:'JetBrains Mono',monospace;}
      .pt-plbl.t{color:#00e676;}.pt-plbl.s{color:#ff4444;margin-top:9px;}
      .pt-pgrid{display:grid;grid-template-columns:repeat(5,1fr);gap:4px;margin-bottom:5px;}
      .pt-pb{padding:5px 2px;border-radius:6px;border:1px solid #1e2535;background:#181d2a;font-size:10px;font-weight:700;font-family:'JetBrains Mono',monospace;cursor:pointer;color:#6b7a99;text-align:center;transition:all .12s;}
      .pt-pb:hover{color:#e8ecf4;border-color:rgba(79,140,255,.3);}
      .pt-pb.at{background:rgba(0,230,118,.1);border-color:#00e676;color:#00e676;}
      .pt-pb.as{background:rgba(255,68,68,.1);border-color:#ff4444;color:#ff4444;}
      .pt-pb:disabled{opacity:.35;cursor:not-allowed;}
      .pt-crow{display:flex;align-items:center;gap:5px;}
      .pt-clbl{font-size:9px;color:#6b7a99;font-family:'JetBrains Mono',monospace;flex-shrink:0;}
      .pt-cin{width:60px;background:#181d2a;border:1px solid #1e2535;border-radius:6px;padding:4px 7px;font-size:11px;font-weight:700;font-family:'JetBrains Mono',monospace;color:#e8ecf4;outline:none;text-align:center;}
      .pt-cin:focus{border-color:#4f8cff;}
      .pt-cin:disabled{opacity:.35;}
      /* LOT SECTION */
      .pt-lot-section{padding:9px 13px;border-bottom:1px solid #1e2535;background:#0c1019;}
      .pt-lot-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;}
      .pt-lot-title{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:#6b7a99;font-family:'JetBrains Mono',monospace;}
      .pt-instrument-tag{font-size:8px;font-weight:700;font-family:'JetBrains Mono',monospace;padding:2px 7px;border-radius:10px;background:rgba(79,140,255,.1);border:1px solid rgba(79,140,255,.3);color:#4f8cff;}
      .pt-lot-controls{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
      .pt-lot-block{background:#111520;border:1px solid #1e2535;border-radius:8px;padding:7px 9px;}
      .pt-lot-blbl{font-size:7px;text-transform:uppercase;letter-spacing:1.2px;color:#6b7a99;font-family:'JetBrains Mono',monospace;margin-bottom:5px;}
      .pt-lot-ctrl{display:flex;align-items:center;gap:4px;}
      .pt-lot-btn{width:20px;height:20px;border-radius:5px;border:1px solid #1e2535;background:#181d2a;color:#e8ecf4;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1;font-family:'JetBrains Mono',monospace;transition:background .12s;flex-shrink:0;}
      .pt-lot-btn:hover{background:#1e2535;}
      .pt-lot-btn:disabled{opacity:.35;cursor:not-allowed;}
      .pt-lot-inp{flex:1;text-align:center;font-size:13px;font-weight:700;font-family:'JetBrains Mono',monospace;color:#e8ecf4;background:transparent;border:none;outline:none;width:30px;}
      .pt-lot-inp::-webkit-outer-spin-button,.pt-lot-inp::-webkit-inner-spin-button{-webkit-appearance:none;margin:0;}
      .pt-lot-inp[type=number]{-moz-appearance:textfield;}
      .pt-lot-inp:disabled{opacity:.35;}
      .pt-lot-qty-display{margin-top:5px;font-size:9px;color:#6b7a99;font-family:'JetBrains Mono',monospace;text-align:center;}
      .pt-lot-qty-display span{color:#e8ecf4;font-weight:700;}
      /* ACTION BUTTONS */
      .pt-act{padding:10px 13px;}
      .pt-act-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;}
      .pt-abtn{padding:11px;border:none;border-radius:9px;font-size:13px;font-weight:800;font-family:'Syne','Segoe UI',sans-serif;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .15s;letter-spacing:.3px;}
      .pt-abtn.buy{background:linear-gradient(135deg,#00c853,#00e676);color:#000;}
      .pt-abtn.buy:hover{box-shadow:0 4px 16px rgba(0,230,118,.5);transform:translateY(-1px);}
      .pt-abtn.sell{background:linear-gradient(135deg,#ff4444,#c0392b);color:#fff;}
      .pt-abtn.sell:hover{box-shadow:0 4px 16px rgba(255,68,68,.4);transform:translateY(-1px);}
      .pt-abtn.exit{background:linear-gradient(135deg,#f59e0b,#d97706);color:#000;}
      .pt-abtn.exit:hover{box-shadow:0 4px 16px rgba(245,158,11,.4);transform:translateY(-1px);}
      .pt-abtn:disabled{opacity:.4;cursor:not-allowed;transform:none !important;box-shadow:none !important;}
      .pt-abtn:active{transform:translateY(0)!important;}
      .pt-exit-row{display:none;}
      .pt-exit-row.show{display:block;margin-top:6px;}
      /* HISTORY */
      .pt-hist{border-top:1px solid #1e2535;}
      .pt-hist-hdr{display:flex;align-items:center;justify-content:space-between;padding:7px 13px 5px;cursor:pointer;}
      .pt-hist-title{font-size:10px;font-weight:700;color:#6b7a99;letter-spacing:.5px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;}
      .pt-hist-chevron{font-size:10px;color:#6b7a99;transition:transform .2s;}
      .pt-hist-chevron.open{transform:rotate(180deg);}
      .pt-hist-body{display:none;max-height:160px;overflow-y:auto;padding:0 6px 8px;}
      .pt-hist-body.show{display:block;}
      .pt-hist-body::-webkit-scrollbar{width:3px;}
      .pt-hist-body::-webkit-scrollbar-track{background:#0d1117;}
      .pt-hist-body::-webkit-scrollbar-thumb{background:#1e2535;border-radius:2px;}
      .pt-trade-row{display:flex;align-items:center;justify-content:space-between;padding:5px 7px;border-radius:7px;margin-bottom:3px;background:#111520;border:1px solid #1a2030;font-family:'JetBrains Mono',monospace;}
      .pt-tr-dir{font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;}
      .pt-tr-dir.b{background:rgba(0,230,118,.1);color:#00e676;}
      .pt-tr-dir.s{background:rgba(255,68,68,.1);color:#ff4444;}
      .pt-tr-info{font-size:9px;color:#6b7a99;flex:1;text-align:center;}
      .pt-tr-pnl{font-size:10px;font-weight:700;}
      .pt-tr-pnl.pos{color:#00e676;}.pt-tr-pnl.neg{color:#ff4444;}
      .pt-tr-reason{font-size:8px;color:#6b7a99;margin-left:4px;}
      .pt-no-trades{font-size:10px;color:#6b7a99;text-align:center;padding:10px;font-family:'JetBrains Mono',monospace;}
      .pt-clear-btn{font-size:8px;color:#6b7a99;background:none;border:1px solid #1e2535;border-radius:4px;padding:2px 6px;cursor:pointer;font-family:'JetBrains Mono',monospace;}
      .pt-clear-btn:hover{color:#ff4444;border-color:rgba(255,68,68,.3);}
    `;
    document.head.appendChild(s);
  }

  // ─── BUILD PANEL ──────────────────────────────────────────────────────────
  function buildPanel(x, y) {
    const root = document.createElement('div');
    root.id = PANEL_ID;
    root.style.cssText = `left:${x}px;top:${y}px;`;

    root.innerHTML = `
      <div class="pt">
        <div class="pt-bar" id="pt-handle">
          <div class="pt-logo">P</div>
          <span class="pt-title">Paper Trade</span>
          <div class="pt-badge" id="pt-badge"><span class="pt-dot"></span><span id="pt-badge-txt">idle</span></div>
          <div class="pt-x" id="pt-close">&#x2715;</div>
        </div>

        <div class="pt-price">
          <div class="pt-lbl">Live Price</div>
          <div class="pt-price-row"><span class="pt-psym">&#8377;</span><span class="pt-pval" id="pt-pval">&#x2014;</span></div>
          <div class="pt-ptime" id="pt-ptime">waiting for price...</div>
        </div>

        <div class="pt-pnl-bar">
          <div class="pt-pnl-block"><div class="pt-pnl-lbl">Live P&amp;L</div><div class="pt-pnl-val zero" id="pt-live-pnl">&#8377;0.00</div></div>
          <div class="pt-divider"></div>
          <div class="pt-pnl-block"><div class="pt-total-lbl">Session Total</div><div class="pt-total-val zero" id="pt-total-pnl">&#8377;0.00</div></div>
          <div class="pt-divider"></div>
          <div class="pt-pnl-block"><div class="pt-pnl-lbl">Trades</div><div class="pt-total-val zero" id="pt-trade-count">0</div></div>
        </div>

        <div class="pt-trade-info" id="pt-trade-info">
          <div class="pt-ti-row"><span class="pt-ti-lbl">Entry</span><span class="pt-ti-val" id="pt-ti-entry">&#x2014;</span></div>
          <div class="pt-ti-row">
            <span class="pt-ti-lbl">Target</span><span class="pt-ti-val pt-ti-tgt" id="pt-ti-tgt">&#x2014;</span>
            <span class="pt-ti-lbl">SL</span><span class="pt-ti-val pt-ti-sl" id="pt-ti-sl">&#x2014;</span>
          </div>
          <div class="pt-progress"><div class="pt-progress-fill" id="pt-progress-fill" style="width:50%;background:#f59e0b;"></div></div>
        </div>

        <div class="pt-dir">
          <div class="pt-lbl">Direction</div>
          <div class="pt-dir-grid">
            <button class="pt-dbtn ba" id="pt-buy-dir">&#x25B2; BUY</button>
            <button class="pt-dbtn"    id="pt-sell-dir">&#x25BC; SELL</button>
          </div>
        </div>

        <div class="pt-tsl">
          <div class="pt-tbox t"><div class="pt-tlbl" id="pt-tlbl">&#x25B2; Target</div><div class="pt-tval" id="pt-tval">&#x2014;</div><div class="pt-tsub" id="pt-tsub">+30 pts</div></div>
          <div class="pt-tbox s"><div class="pt-tlbl" id="pt-slbl">&#x25BC; Stop Loss</div><div class="pt-tval" id="pt-sval">&#x2014;</div><div class="pt-tsub" id="pt-ssub">-20 pts</div></div>
        </div>

        <div class="pt-pts">
          <div class="pt-plbl t">Target Points</div>
          <div class="pt-pgrid" id="pt-tgrid"></div>
          <div class="pt-crow"><span class="pt-clbl">Custom:</span><input class="pt-cin" id="pt-tcust" type="number" min="1" placeholder="pts"/><span class="pt-clbl" style="color:#00e676">&#x25B2;pts</span></div>
          <div class="pt-plbl s">SL Points</div>
          <div class="pt-pgrid" id="pt-sgrid"></div>
          <div class="pt-crow"><span class="pt-clbl">Custom:</span><input class="pt-cin" id="pt-scust" type="number" min="1" placeholder="pts"/><span class="pt-clbl" style="color:#ff4444">&#x25BC;pts</span></div>
        </div>

        <!-- LOT AND QUANTITY SECTION -->
        <div class="pt-lot-section">
          <div class="pt-lot-header">
            <span class="pt-lot-title">Lot Size &amp; Quantity</span>
            <span class="pt-instrument-tag" id="pt-instrument-tag">NIFTY</span>
          </div>
          <div class="pt-lot-controls">
            <div class="pt-lot-block">
              <div class="pt-lot-blbl">Lots</div>
              <div class="pt-lot-ctrl">
                <button class="pt-lot-btn" id="pt-lots-minus">&#x2212;</button>
                <input class="pt-lot-inp" id="pt-lots-val" type="number" min="1" value="1"/>
                <button class="pt-lot-btn" id="pt-lots-plus">+</button>
              </div>
              <div class="pt-lot-qty-display">Qty: <span id="pt-total-qty">65</span></div>
            </div>
            <div class="pt-lot-block">
              <div class="pt-lot-blbl">Qty / Lot</div>
              <div class="pt-lot-ctrl">
                <button class="pt-lot-btn" id="pt-lotsize-minus">&#x2212;</button>
                <input class="pt-lot-inp" id="pt-lotsize-val" type="number" min="1" value="65"/>
                <button class="pt-lot-btn" id="pt-lotsize-plus">+</button>
              </div>
              <div class="pt-lot-qty-display">Total: <span id="pt-total-qty2">65</span></div>
            </div>
          </div>
        </div>

        <div class="pt-act">
          <div class="pt-act-grid" id="pt-buy-sell-row">
            <button class="pt-abtn buy" id="pt-do-buy">&#x25B2; BUY</button>
            <button class="pt-abtn sell" id="pt-do-sell">&#x25BC; SELL</button>
          </div>
          <div class="pt-exit-row" id="pt-exit-row">
            <button class="pt-abtn exit" id="pt-do-exit" style="width:100%;">&#x2715; Exit Trade at Market</button>
          </div>
        </div>

        <div class="pt-hist">
          <div class="pt-hist-hdr" id="pt-hist-hdr">
            <span class="pt-hist-title">&#x1F4CB; Trade History</span>
            <button class="pt-clear-btn" id="pt-clear-btn">Clear All</button>
            <span class="pt-hist-chevron" id="pt-hist-chev">&#x25BC;</span>
          </div>
          <div class="pt-hist-body" id="pt-hist-body"></div>
        </div>
      </div>`;

    document.body.appendChild(root);
    buildGrids();
    refreshAll();
    wireEvents(root);
    makeDraggable(root, document.getElementById('pt-handle'));
  }

  // ─── GRIDS ────────────────────────────────────────────────────────────────
  function buildGrids() {
    ['pt-tgrid', 'pt-sgrid'].forEach((id, i) => {
      const g = document.getElementById(id);
      if (!g) return;
      g.innerHTML = '';
      PT_OPTIONS.forEach(pts => {
        const b = document.createElement('button');
        b.className = 'pt-pb';
        b.textContent = pts;
        b.dataset.pts = pts;
        b.addEventListener('click', () => {
          if (i === 0) { state.targetPts = pts; document.getElementById('pt-tcust').value = ''; }
          else         { state.slPts     = pts; document.getElementById('pt-scust').value = ''; }
          refreshAll(); saveState();
        });
        g.appendChild(b);
      });
    });
  }

  // ─── REFRESH ──────────────────────────────────────────────────────────────
  function refreshAll() {
    refreshGridHighlights(); refreshDirection(); refreshTSL(); refreshBadge();
    refreshPnl(); refreshTradeInfo(); refreshTradeHistory(); refreshButtons(); refreshLots();
  }

  function refreshGridHighlights() {
    document.querySelectorAll('#pt-tgrid .pt-pb').forEach(b => b.classList.toggle('at', parseInt(b.dataset.pts) === state.targetPts));
    document.querySelectorAll('#pt-sgrid .pt-pb').forEach(b => b.classList.toggle('as', parseInt(b.dataset.pts) === state.slPts));
  }

  function refreshDirection() {
    const bb = document.getElementById('pt-buy-dir');
    const sb = document.getElementById('pt-sell-dir');
    if (!bb || !sb) return;
    bb.className = 'pt-dbtn' + (state.direction === 'BUY'  ? ' ba' : '');
    sb.className = 'pt-dbtn' + (state.direction === 'SELL' ? ' sa' : '');
    bb.disabled = state.inTrade; sb.disabled = state.inTrade;
  }

  function refreshTSL() {
    const p = state.inTrade ? state.entryPrice : state.price;
    const isBuy = state.direction === 'BUY';
    const tlbl = document.getElementById('pt-tlbl'); if (!tlbl) return;
    const slbl = document.getElementById('pt-slbl');
    const tval = document.getElementById('pt-tval');
    const sval = document.getElementById('pt-sval');
    const tsub = document.getElementById('pt-tsub');
    const ssub = document.getElementById('pt-ssub');
    tlbl.textContent = isBuy ? '\u25B2 Target' : '\u25BC Target';
    slbl.textContent = isBuy ? '\u25BC Stop Loss' : '\u25B2 Stop Loss';
    tsub.textContent = isBuy ? `+${state.targetPts} pts` : `-${state.targetPts} pts`;
    ssub.textContent = isBuy ? `-${state.slPts} pts`     : `+${state.slPts} pts`;
    if (state.inTrade && state.targetPrice && state.slPrice) {
      tval.textContent = '\u20B9' + state.targetPrice.toFixed(2);
      sval.textContent = '\u20B9' + state.slPrice.toFixed(2);
    } else if (p) {
      const tv = isBuy ? (p + state.targetPts).toFixed(2) : Math.max(0.05, p - state.targetPts).toFixed(2);
      const sv = isBuy ? Math.max(0.05, p - state.slPts).toFixed(2) : (p + state.slPts).toFixed(2);
      tval.textContent = '\u20B9' + tv; sval.textContent = '\u20B9' + sv;
    } else { tval.textContent = '\u2014'; sval.textContent = '\u2014'; }
  }

  function refreshBadge() {
    const el = document.getElementById('pt-badge'); const txt = document.getElementById('pt-badge-txt');
    if (!el) return;
    if (state.inTrade) { el.className = 'pt-badge intrade'; if (txt) txt.textContent = state.direction === 'BUY' ? 'long' : 'short'; }
    else if (state.price) { el.className = 'pt-badge live'; if (txt) txt.textContent = 'live'; }
    else { el.className = 'pt-badge'; if (txt) txt.textContent = 'idle'; }
  }

  function refreshPnl() {
    const liveEl = document.getElementById('pt-live-pnl');
    const totEl  = document.getElementById('pt-total-pnl');
    const cntEl  = document.getElementById('pt-trade-count');
    const livePnl = state.inTrade && state.price && state.entryPrice ? calcLivePnl(state.price) : 0;
    if (liveEl) { liveEl.textContent = formatPnl(livePnl); liveEl.className = 'pt-pnl-val ' + pnlClass(livePnl); }
    if (totEl)  { totEl.textContent  = formatPnl(state.totalPnl); totEl.className = 'pt-total-val ' + pnlClass(state.totalPnl); }
    if (cntEl)  { cntEl.textContent  = state.trades.length; cntEl.className = 'pt-total-val ' + (state.trades.length > 0 ? 'pos' : 'zero'); }
  }

  function refreshTradeInfo() {
    const infoEl = document.getElementById('pt-trade-info'); if (!infoEl) return;
    if (!state.inTrade || !state.entryPrice) { infoEl.classList.remove('show'); return; }
    infoEl.classList.add('show');
    const qty = totalQty();
    document.getElementById('pt-ti-entry').textContent =
      `\u20B9${state.entryPrice.toFixed(2)} (${state.direction} ${state.lots}L\u00D7${state.lotSize}=${qty})`;
    document.getElementById('pt-ti-tgt').textContent = state.targetPrice ? '\u20B9' + state.targetPrice.toFixed(2) : '\u2014';
    document.getElementById('pt-ti-sl').textContent  = state.slPrice     ? '\u20B9' + state.slPrice.toFixed(2)     : '\u2014';
    if (state.price && state.targetPrice && state.slPrice) {
      const range = Math.abs(state.targetPrice - state.slPrice);
      let pct = state.direction === 'BUY'
        ? ((state.price - state.slPrice) / range) * 100
        : ((state.slPrice - state.price) / range) * 100;
      pct = Math.max(0, Math.min(100, pct));
      const fill = document.getElementById('pt-progress-fill');
      if (fill) { fill.style.width = pct + '%'; fill.style.background = pct > 65 ? '#00e676' : pct > 35 ? '#f59e0b' : '#ff4444'; }
    }
  }

  function refreshTradeHistory() {
    const body = document.getElementById('pt-hist-body'); if (!body) return;
    if (state.trades.length === 0) { body.innerHTML = '<div class="pt-no-trades">No trades yet</div>'; return; }
    body.innerHTML = [...state.trades].reverse().map(t =>
      `<div class="pt-trade-row">
        <span class="pt-tr-dir ${t.direction === 'BUY' ? 'b' : 's'}">${t.direction}</span>
        <span class="pt-tr-info">${t.entry.toFixed(1)}\u2192${t.exit.toFixed(1)} ${t.lots}L(${t.qty})</span>
        <span class="pt-tr-pnl ${t.pnl >= 0 ? 'pos' : 'neg'}">${formatPnl(t.pnl)}</span>
        <span class="pt-tr-reason">${t.reason}</span>
      </div>`).join('');
  }

  function refreshLots() {
    const lotsInp    = document.getElementById('pt-lots-val');
    const lotSizeInp = document.getElementById('pt-lotsize-val');
    const totalQtyEl = document.getElementById('pt-total-qty');
    const totalQty2  = document.getElementById('pt-total-qty2');
    const instrTag   = document.getElementById('pt-instrument-tag');
    if (lotsInp)    lotsInp.value    = state.lots;
    if (lotSizeInp) lotSizeInp.value = state.lotSize;
    const qty = totalQty();
    if (totalQtyEl) totalQtyEl.textContent = qty;
    if (totalQty2)  totalQty2.textContent  = qty;
    if (instrTag)   instrTag.textContent   = state.instrument;
    const dis = state.inTrade;
    ['pt-lots-minus','pt-lots-plus','pt-lotsize-minus','pt-lotsize-plus'].forEach(id => {
      const el = document.getElementById(id); if (el) el.disabled = dis;
    });
    if (lotsInp)    lotsInp.disabled    = dis;
    if (lotSizeInp) lotSizeInp.disabled = dis;
  }

  function refreshButtons() {
    const exitRow = document.getElementById('pt-exit-row');
    document.querySelectorAll('#pt-tgrid .pt-pb, #pt-sgrid .pt-pb').forEach(b => b.disabled = state.inTrade);
    document.querySelectorAll('#pt-tcust, #pt-scust').forEach(el => el.disabled = state.inTrade);
    if (state.inTrade) { if (exitRow) exitRow.classList.add('show'); }
    else               { if (exitRow) exitRow.classList.remove('show'); }
    const buyBtn  = document.getElementById('pt-do-buy');
    const sellBtn = document.getElementById('pt-do-sell');
    if (buyBtn)  buyBtn.disabled  = !state.price || state.inTrade;
    if (sellBtn) sellBtn.disabled = !state.price || state.inTrade;
  }

  // ─── WIRE EVENTS ──────────────────────────────────────────────────────────
  function wireEvents() {
    document.getElementById('pt-close').addEventListener('click', hidePanel);
    document.getElementById('pt-buy-dir').addEventListener('click', () => { if (state.inTrade) return; state.direction = 'BUY';  refreshAll(); saveState(); });
    document.getElementById('pt-sell-dir').addEventListener('click',() => { if (state.inTrade) return; state.direction = 'SELL'; refreshAll(); saveState(); });
    document.getElementById('pt-tcust').addEventListener('change', (e) => { const v = parseInt(e.target.value); if (v > 0) { state.targetPts = v; refreshAll(); saveState(); } });
    document.getElementById('pt-scust').addEventListener('change', (e) => { const v = parseInt(e.target.value); if (v > 0) { state.slPts     = v; refreshAll(); saveState(); } });

    // Lots
    document.getElementById('pt-lots-minus').addEventListener('click', () => { if (state.lots > 1) { state.lots--; refreshAll(); saveState(); } });
    document.getElementById('pt-lots-plus').addEventListener('click',  () => { state.lots++; refreshAll(); saveState(); });
    document.getElementById('pt-lots-val').addEventListener('change',  (e) => { const v = parseInt(e.target.value); if (v >= 1) { state.lots = v; refreshAll(); saveState(); } else e.target.value = state.lots; });

    // Lot size
    document.getElementById('pt-lotsize-minus').addEventListener('click', () => { if (state.lotSize > 1) { state.lotSize--; refreshAll(); saveState(); } });
    document.getElementById('pt-lotsize-plus').addEventListener('click',  () => { state.lotSize++; refreshAll(); saveState(); });
    document.getElementById('pt-lotsize-val').addEventListener('change',  (e) => { const v = parseInt(e.target.value); if (v >= 1) { state.lotSize = v; refreshAll(); saveState(); } else e.target.value = state.lotSize; });

    document.getElementById('pt-do-buy').addEventListener('click',  () => enterTrade('BUY'));
    document.getElementById('pt-do-sell').addEventListener('click', () => enterTrade('SELL'));
    document.getElementById('pt-do-exit').addEventListener('click', () => exitTrade('manual'));

    document.getElementById('pt-hist-hdr').addEventListener('click', (e) => {
      if (e.target.id === 'pt-clear-btn') return;
      document.getElementById('pt-hist-body').classList.toggle('show');
      document.getElementById('pt-hist-chev').classList.toggle('open');
    });
    document.getElementById('pt-clear-btn').addEventListener('click', () => { state.trades = []; state.totalPnl = 0; refreshAll(); saveState(); });
  }

  // ─── DRAGGABLE ────────────────────────────────────────────────────────────
  function makeDraggable(panel, handle) {
    let drag = false, ox = 0, oy = 0;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.id === 'pt-close') return;
      drag = true; const r = panel.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      document.body.style.userSelect = 'none'; e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!drag) return;
      panel.style.left = Math.max(0, Math.min(window.innerWidth  - panel.offsetWidth,  e.clientX - ox)) + 'px';
      panel.style.top  = Math.max(0, Math.min(window.innerHeight - panel.offsetHeight, e.clientY - oy)) + 'px';
    });
    document.addEventListener('mouseup', () => {
      if (!drag) return; drag = false; document.body.style.userSelect = '';
      chrome.storage.local.set({ panelX: parseInt(document.getElementById(PANEL_ID).style.left), panelY: parseInt(document.getElementById(PANEL_ID).style.top) });
    });
  }

  // ─── PRICE SCRAPING ──────────────────────────────────────────────────────
  function getLivePrice() {
    for (const sel of ['.stockLtp','[class*="stockLtp"]','.ltp','[class*="ltp"]','.price-value']) {
      const el = document.querySelector(sel);
      if (el) { const n = parseFloat(el.innerText.replace(/[₹,\s]/g, '')); if (!isNaN(n) && n > 0) return n; }
    }
    const b = document.querySelector('.stockLtp .bold-text');
    const l = document.querySelector('.stockLtp .light-text');
    if (b && l) { const n = parseFloat((b.innerText + l.innerText).replace(/[^0-9.]/g, '')); if (!isNaN(n)) return n; }
    return null;
  }

  function startPricePoll() {
    if (intervalId) clearInterval(intervalId);
    intervalId = setInterval(() => {
      if (!panelVisible) return;
      const p = getLivePrice(); if (!p) return;
      state.prevPrice = state.price; state.price = p;
      const pv = document.getElementById('pt-pval'); const pt = document.getElementById('pt-ptime');
      if (pv) { pv.textContent = p.toFixed(2); const dir = state.prevPrice ? (p > state.prevPrice ? 'up' : p < state.prevPrice ? 'down' : '') : ''; pv.className = 'pt-pval' + (dir ? ' ' + dir : ''); }
      if (pt) pt.textContent = 'Updated: ' + new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
      refreshTSL(); refreshBadge(); refreshButtons();
      if (state.inTrade) { refreshPnl(); refreshTradeInfo(); checkAutoExit(p); }
    }, 1000);
  }

  // ─── TRADE LOGIC ──────────────────────────────────────────────────────────
  function enterTrade(dir) {
    if (!state.price) return;
    state.direction = dir; state.inTrade = true; state.entryPrice = state.price;
    const isBuy = dir === 'BUY';
    state.targetPrice = isBuy ? state.price + state.targetPts : Math.max(0.05, state.price - state.targetPts);
    state.slPrice     = isBuy ? Math.max(0.05, state.price - state.slPts) : state.price + state.slPts;
    refreshAll();
    const qty = totalQty();
    showToast(`${dir} @ \u20B9${state.entryPrice.toFixed(2)} | ${state.lots}L \u00D7 ${state.lotSize} = ${qty} qty | TGT \u20B9${state.targetPrice.toFixed(2)} | SL \u20B9${state.slPrice.toFixed(2)}`, dir === 'BUY' ? '#00e676' : '#ff4444');
  }

  function exitTrade(reason) {
    if (!state.inTrade || !state.price) return;
    const pnl = calcLivePnl(state.price);
    state.trades.push({ direction: state.direction, entry: state.entryPrice, exit: state.price, lots: state.lots, qty: totalQty(), pnl, reason, time: new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }) });
    state.totalPnl += pnl; state.pnl = 0; state.inTrade = false;
    state.entryPrice = null; state.targetPrice = null; state.slPrice = null;
    refreshAll(); saveState();
    const label = reason === 'target' ? '\uD83C\uDFAF Target Hit' : reason === 'sl' ? '\uD83D\uDED1 SL Hit' : '\u2715 Manual Exit';
    showToast(`${label}: ${formatPnl(pnl)}`, pnl >= 0 ? '#00e676' : '#ff4444');
  }

  function checkAutoExit(price) {
    if (!state.inTrade) return;
    if (state.direction === 'BUY') {
      if (price >= state.targetPrice) { exitTrade('target'); return; }
      if (price <= state.slPrice)     { exitTrade('sl');     return; }
    } else {
      if (price <= state.targetPrice) { exitTrade('target'); return; }
      if (price >= state.slPrice)     { exitTrade('sl');     return; }
    }
  }

  // ─── PNL ──────────────────────────────────────────────────────────────────
  function calcLivePnl(currentPrice) {
    if (!state.entryPrice) return 0;
    const diff = state.direction === 'BUY' ? currentPrice - state.entryPrice : state.entryPrice - currentPrice;
    return diff * totalQty();
  }
  function formatPnl(v) { return (v >= 0 ? '+' : '') + '\u20B9' + Math.abs(v).toFixed(2); }
  function pnlClass(v)  { return v > 0 ? 'pos' : v < 0 ? 'neg' : 'zero'; }

  // ─── TOAST ────────────────────────────────────────────────────────────────
  function showToast(msg, color) {
    const t = document.createElement('div');
    t.style.cssText = `position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(0);background:#111520;border:1px solid ${color};color:${color};font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;padding:8px 16px;border-radius:8px;z-index:2147483647;box-shadow:0 4px 20px rgba(0,0,0,.6);transition:opacity .4s,transform .4s;pointer-events:none;`;
    t.textContent = msg; document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(-50%) translateY(10px)'; }, 2500);
    setTimeout(() => t.remove(), 3000);
  }

  // ─── SAVE ─────────────────────────────────────────────────────────────────
  function saveState() {
    chrome.storage.local.set({ targetPts: state.targetPts, slPts: state.slPts, direction: state.direction, lots: state.lots, lotSize: state.lotSize, instrument: state.instrument, totalPnl: state.totalPnl, trades: state.trades.slice(-50) });
  }

})();
